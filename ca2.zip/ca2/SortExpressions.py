class SortExpressions:
    def run(self):
        print('Not implemented yet')

    def __str__(self):
        return 'Sort expressions'